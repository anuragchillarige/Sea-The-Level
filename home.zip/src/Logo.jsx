import React from 'react';

function Logo() {
    return <h2>Product</h2>
}

export default Logo;