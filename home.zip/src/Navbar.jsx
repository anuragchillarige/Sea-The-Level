import React from 'react';
import './Styles/NavBar.css';
import './Logo.jsx';

function Navbar() {
    return (
        <nav>
            <h2>Product</h2>
            <div>
                <button>Home</button>
                <button>Graph</button>
                <button>Predict</button>
            </div>
        </nav>
    )

}

export default Navbar; 
