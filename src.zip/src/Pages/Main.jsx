import React from 'react';
import "../Styles/Main.css"
import Navbar from '../Components/Navbar';
import Graph from '../Components/Graph';
function Main() {
    return (
        <>
            <div className="backdrop"></div>
            <Navbar />
            <Graph />
        </>
    );
}

export default Main;