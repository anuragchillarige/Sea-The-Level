import { React } from 'react';

function Graph() {
    return (
        <div class="content container">
            <h1 class="title graph">GRAPH AREA</h1>
            <div className="imageText">
                <p class="image-description">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi est voluptatibus cumque sint nulla commodi alias iusto consequatur ipsa, delectus quis? Recusandae nam magni eligendi eos quasi nesciunt laborum eaque.
                    Rem inventore praesentium ea ex, reiciendis necessitatibus repellendus eveniet voluptatibus, voluptatem, dolore voluptatum quibusdam sed sint earum incidunt ad ullam laborum culpa eius perferendis odit veniam hic at placeat. Officiis!
                    Adipisci eligendi quam et! Vel molestiae quo corporis deleniti iste corrupti qui ratione itaque quis sit? Quos minus saepe necessitatibus vel autem culpa temporibus rerum, totam rem labore odio reprehenderit.
                </p>
                <div className="image-placeholder"></div>
            </div>

        </div>
    )
}

export default Graph;