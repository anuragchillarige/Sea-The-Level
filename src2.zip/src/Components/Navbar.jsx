import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import { MdClose } from "react-icons/md"
import { FiMenu } from "react-icons/fi"
import '../Styles/Navbar.css';
import logo from '../logo.png';

const navSlide = () => {
    const burger = document.querySelector('.burger');
    const nav = document.querySelector('.navContainer');
    burger.addEventListener('click', () => {
        nav.classList.toggle('nav-active');
    });
}

const Navbar = () => {
    const [navbarOpen, setNavbarOpen] = useState(false);
    const [nav, setNav] = useState(false);
    const [navbarClose] = useState();
    const handleToggle = () => {
        setNavbarOpen(prev => !prev)
    };

    const closeMenu = () => {
        setNavbarOpen(false)
    };

    const changeBackground = () => {
        if (window.scrollY >= 50) {
            setNav(true)
        } else {
            setNav(false)
        }
    };
    window.addEventListener('scroll', changeBackground)

    return (
        <><div className={nav ? 'nav active' : 'nav'}>
            <div className="navTitle">
                <img src={logo}></img>
            </div>
            <div className="navContainer">
                <button className="navButton">
                    Home
                </button>
                <button className="navButton">
                    Analyze
                </button>
                <div className="navButton3">
                    Predict
                </div>
            </div>
            <nav className="navBar">
                <button onClick={handleToggle}>
                    {navbarOpen ? (
                        <MdClose style={{ color: "white", width: "40px", height: "40px" }} />
                    ) : (
                        <FiMenu style={{ color: "white", width: "40px", height: "40px" }} />
                    )}
                </button>
                <div className={`menuNav ${navbarOpen ? " showMenu" : " closeMenu"}`}>
                    <div className='container1'>
                        <div className="option-container">
                            <button onClick={handleToggle}>
                                <MdClose style={{ color: "black", width: "40px", height: "40px" }} />
                            </button>
                            <div className="navB">
                                Home
                            </div>
                            <div className="navB">
                                Analyze
                            </div>
                            <div className="navB">
                                Predict
                            </div>
                        </div>
                        <div className='container2'>
                        </div>
                    </div>
                </div>
            </nav>
            <div>
            </div>

        </div >
        </>
    );
};

export default Navbar;